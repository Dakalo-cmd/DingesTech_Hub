<?php
declare(strict_types=1);
/**
 * Dinges Tech — Public contact form → Bitrix24 Lead
 * File: /home/register/public_html/api/integrations/contact_lead.php
 *
 * Companion to webhook_bitrix.php (which is INBOUND, Bitrix -> here on
 * Deal Won). This script is OUTBOUND: the public contact form on
 * contact.html posts here, and this script — server-side only — creates
 * the Bitrix Lead using the webhook URL stored in config.php.
 *
 * The webhook URL/token is never sent to the browser. It is only ever
 * read here, from config.php, on the server.
 */

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

require_once __DIR__ . '/bootstrap.php';
$config = require __DIR__ . '/config.php';

// ---- CORS: only your own site may call this -----------------------

$allowedOrigins = [
    'https://dingestech.co.za',
    'https://www.dingestech.co.za',
];
$origin = isset($_SERVER['HTTP_ORIGIN']) ? (string) $_SERVER['HTTP_ORIGIN'] : '';
if (in_array($origin, $allowedOrigins, true)) {
    header('Access-Control-Allow-Origin: ' . $origin);
}
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

if (empty($config['enabled']['bitrix'])) {
    http_response_code(503);
    echo json_encode(['success' => false, 'message' => 'Bitrix integration disabled']);
    exit;
}

$webhookUrl = isset($config['bitrix']['webhook_url']) ? (string) $config['bitrix']['webhook_url'] : '';
if ($webhookUrl === '') {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Bitrix webhook not configured']);
    exit;
}

// ---- READ INPUT -----------------------------------------------------

$raw = file_get_contents('php://input');
$data = json_decode($raw !== false ? $raw : '', true);
if (!is_array($data)) {
    $data = $_POST;
}

function dth_clean($v): string
{
    return trim(strip_tags((string) ($v ?? '')));
}

$name            = dth_clean($data['name'] ?? '');
$email           = dth_clean($data['email'] ?? '');
$phone           = dth_clean($data['phone'] ?? '');
$subject         = dth_clean($data['subject'] ?? '');
$reason          = dth_clean($data['reason'] ?? '');
$contactLocation = dth_clean($data['contactLocation'] ?? '');
$message         = dth_clean($data['message'] ?? '');

// Honeypot: a hidden field real users never fill in
if (!empty($data['website'])) {
    echo json_encode(['success' => true]);
    exit;
}

if ($name === '' || $email === '' || $message === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Name, email and message are required.']);
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid email address.']);
    exit;
}

// ---- BUILD LEAD -------------------------------------------------------

$title = 'Website contact: ' . ($subject !== '' ? $subject : $name);
$comments = "Reason: " . ($reason !== '' ? $reason : 'n/a') . "\n" .
            "Location: " . ($contactLocation !== '' ? $contactLocation : 'n/a') . "\n\n" .
            $message;

$fields = [
    'fields' => [
        'TITLE'              => $title,
        'NAME'               => $name,
        'EMAIL'              => [['VALUE' => $email, 'VALUE_TYPE' => 'WORK']],
        'COMMENTS'           => $comments,
        'SOURCE_ID'          => 'WEB',
        'SOURCE_DESCRIPTION' => 'Dinges Tech website contact form',
        'ASSIGNED_BY_ID'     => $config['bitrix']['assigned_by_id'] ?? 0,
    ],
];
if ($phone !== '') {
    $fields['fields']['PHONE'] = [['VALUE' => $phone, 'VALUE_TYPE' => 'WORK']];
}

// ---- SEND TO BITRIX (server-side; token never leaves this file) -------

$ch = curl_init(rtrim($webhookUrl, '/') . '/crm.lead.add.json');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS     => json_encode($fields),
    CURLOPT_TIMEOUT        => 15,
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($response === false) {
    http_response_code(502);
    echo json_encode(['success' => false, 'message' => 'Could not reach CRM. Please try WhatsApp or call 010 141 5650.']);
    exit;
}

$result = json_decode($response, true);

if ($httpCode >= 200 && $httpCode < 300 && isset($result['result'])) {
    echo json_encode(['success' => true, 'leadId' => $result['result']]);
} else {
    http_response_code(502);
    echo json_encode([
        'success' => false,
        'message' => $result['error_description'] ?? 'Could not send. Please call 010 141 5650.',
    ]);
}
